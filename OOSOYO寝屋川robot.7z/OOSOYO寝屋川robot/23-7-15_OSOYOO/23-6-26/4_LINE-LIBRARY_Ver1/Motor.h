#ifndef _Motor_H_
#define _Motor_H_
#include "Arduino.h"

class Motor{
  public:
    Motor();
    void  go_Advance(int speed);
    void  go_Back(int speed);
    void  stop_Stop();
    void  turn(int angle);
    
    #define LFSensor_0 A0  //OLD D3
    #define LFSensor_1 A1
    #define LFSensor_2 A2
    #define LFSensor_3 A3
    #define LFSensor_4 A4  //OLD D10
  private:
    const int IN1= 7;
    const int IN2= 8;
    const int ENA= 5; 
    const int STEER_PIN= 9;  //steer
   
};
#endif
