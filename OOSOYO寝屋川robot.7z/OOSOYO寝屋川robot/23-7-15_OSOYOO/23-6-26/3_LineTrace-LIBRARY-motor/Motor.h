#ifndef _Motor_H_
#define _Motor_H_
#include "Arduino.h"

class Motor{
  public:
    Motor();
    void  go_Advance(int speed);
    void  go_Back(int speed);
    void  stop_Stop();
    void  turn(int angle);
    const int STEER_PIN= 9;  //steer
  private:
    const int IN1= 7;
    const int IN2= 8;
    const int ENA= 5; 
    
};
#endif
