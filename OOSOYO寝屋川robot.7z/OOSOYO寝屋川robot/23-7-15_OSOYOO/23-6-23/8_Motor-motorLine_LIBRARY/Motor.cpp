#include "Arduino.h"
#include "Motor.h"
#include "PWMServo.h"
PWMServo head;
char sensor[5];
 //String sensorval;
 Motor::Motor(){
  Serial.begin(115200);
  pinMode(ENA,OUTPUT); 
  pinMode(IN1,OUTPUT); 
  pinMode(IN2, OUTPUT); 
 }
 void Motor::turn(int angle)
{
  head.attach(STEER_pin);
  head.write(angle);
}
void Motor::Forward(int speed)  //Forward
{
  digitalWrite(IN1, LOW);
  digitalWrite(IN2,HIGH); 
  analogWrite(ENA,speed); 
}
void Motor::Back(int speed)  
{
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2,LOW); 
  analogWrite(ENA,speed);
}
void Motor::Stop()    //Stop
{
  digitalWrite(IN1, LOW);
  digitalWrite(IN2,LOW);
  analogWrite(ENA,0);
}
void Motor::tracking(String){
  
  
 int sensorvalue=32;
  sensor[0]= !digitalRead(LFSensor_0);
 
  sensor[1]=!digitalRead(LFSensor_1);
 
  sensor[2]=!digitalRead(LFSensor_2);
 
  sensor[3]=!digitalRead(LFSensor_3);
 
  sensor[4]=!digitalRead(LFSensor_4);
  sensorvalue +=sensor[0]*16+sensor[1]*8+sensor[2]*4+sensor[3]*2+sensor[4];
  
  String sensorval= String(sensorvalue,BIN).substring(1,6);
  
 Serial.print("VALUE=");
  Serial.println(sensorval);
    if (sensorval=="00000" )
  {
    turn(90);
    Back(160);
    delay(1000);
  }
}
