#include "Arduino.h"
#include "Motor.h"
#include "PWMServo.h"
PWMServo head;
 #define IN1 7
 #define IN2 8
 #define ENA 5 
 #define SERVO_PIN 9  //stearing
 #define SERVO_PIN 10  //Ping
 Motor::Motor(){
  pinMode(ENA,OUTPUT); 
  pinMode(IN1,OUTPUT); 
  pinMode(IN2, OUTPUT); 
 }
 void Motor::turn(int angle)
{
  head.attach(SERVO_PIN);
  head.write(angle);
}
void Motor::Forward(int speed)  //Forward
{
  digitalWrite(IN1, LOW);
  digitalWrite(IN2,HIGH); 
  analogWrite(ENA,speed); 
}
void Motor::Back(int speed)  
{
  digitalWrite(IN1, HIGH);
  digitalWrite(IN2,LOW); 
  analogWrite(ENA,speed);
}
void Motor::Stop()    //Stop
{
  digitalWrite(IN1, LOW);
  digitalWrite(IN2,LOW);
  analogWrite(ENA,0);
}
