#include "Arduino.h"
#include "Line.h"
char sensor[5];  

Line::Line(){     
Serial.begin(115200);
}
void Line::trace(){
 int sensorvalue=32;
  sensor[0]= !digitalRead(LFSensor_0);
  sensor[1]=!digitalRead(LFSensor_1);
  sensor[2]=!digitalRead(LFSensor_2);
  sensor[3]=!digitalRead(LFSensor_3);
  sensor[4]=!digitalRead(LFSensor_4);
  sensorvalue +=sensor[0]*16+sensor[1]*8+sensor[2]*4+sensor[3]*2+sensor[4];  
  String sensorval= String(sensorvalue,BIN).substring(1,6);
  
 Serial.print("VALUE=");
  Serial.println(sensorval);
}
