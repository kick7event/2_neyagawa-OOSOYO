#ifndef _Line_H_
#define _Line_H_
#include "Arduino.h"


class Line{
  public:
    Line();
    void trace();
  private:
    #define LFSensor_0 A0  //OLD D3
    #define LFSensor_1 A1
    #define LFSensor_2 A2
    #define LFSensor_3 A3
    #define LFSensor_4 A4  //OLD D10
};
#endif
