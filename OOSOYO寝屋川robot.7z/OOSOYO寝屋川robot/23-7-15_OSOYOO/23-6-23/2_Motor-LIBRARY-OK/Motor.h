#ifndef _Motor_H_
#define _Motor_H_
#include "Arduino.h"


class Motor{
  public:
    Motor();
    void turn(int angle);
    void Forward(int speed);
    void Back(int speed);
    void Stop();
  private:
    const int IN1= 7;
    const int IN2= 8;
    const int ENA= 5; 
};
#endif
