#ifndef _Motor_H_
#define _Motor_H_
#include "Arduino.h"


class Motor{
  public:
    Motor();
    void turn(int angle);
    void Forward(int speed);
    void Back(int speed);
    void Stop();
  private:
    const int IN1= 7;
    const int IN2= 8;
    const int ENA= 5; 
    #define STEER_pin 9  //steer 
    #define LFSensor_0 A0  //OLD D3
    #define LFSensor_1 A1
    #define LFSensor_2 A2
    #define LFSensor_3 A3
    #define LFSensor_4 A4  //OLD D10
};
#endif
