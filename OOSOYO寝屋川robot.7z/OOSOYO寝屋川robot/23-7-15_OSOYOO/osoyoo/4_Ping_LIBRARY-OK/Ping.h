#ifndef _Ping_H_
#define _Ping_H_
#include "Arduino.h"


class Ping{
  public:
    Ping();
    void watch();
    
  private:
    #define Echo_PIN    2 // Ultrasonic Echo pin connect to D11
    #define Trig_PIN    3  // Ultrasonic Trig pin connect to D12

    
};
#endif
