#include "Arduino.h"
#include "Ping.h"
Ping::Ping(){
  long distance;
  pinMode(Trig_PIN, OUTPUT); 
  pinMode(Echo_PIN,INPUT); 
}


void Ping::watch(){
  long distance;
  digitalWrite(Trig_PIN,LOW);
  delayMicroseconds(5);                                                                              
  digitalWrite(Trig_PIN,HIGH);
  delayMicroseconds(15);
  digitalWrite(Trig_PIN,LOW);
  distance=pulseIn(Echo_PIN,HIGH);
  distance=distance*0.01657; //how far away is the object in cm
  Serial.println((int)distance);
  return round(distance);
}
